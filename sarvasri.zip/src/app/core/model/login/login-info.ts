export class LoginInfo {
      username: string = "";
      password: string = "";
      logintime: string = "";
      ipaddress: string = "";
      deviceid: string = "";
      logintype: string = "";
}