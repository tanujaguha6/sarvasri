import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-first-income-deduction',
  templateUrl: './first-income-deduction.component.html',
  styleUrls: ['./first-income-deduction.component.scss']
})
export class FirstIncomeDeductionComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
