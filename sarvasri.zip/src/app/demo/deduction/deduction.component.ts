import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-deduction',
  templateUrl: './deduction.component.html',
  styleUrls: ['./deduction.component.scss']
})
export class DeductionComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
