import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-payout-report',
  templateUrl: './payout-report.component.html',
  styleUrls: ['./payout-report.component.scss']
})
export class PayoutReportComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
