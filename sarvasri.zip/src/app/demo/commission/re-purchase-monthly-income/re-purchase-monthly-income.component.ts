import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-re-purchase-monthly-income',
  templateUrl: './re-purchase-monthly-income.component.html',
  styleUrls: ['./re-purchase-monthly-income.component.scss']
})
export class RePurchaseMonthlyIncomeComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
