import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-re-purchase-weekly-income',
  templateUrl: './re-purchase-weekly-income.component.html',
  styleUrls: ['./re-purchase-weekly-income.component.scss']
})
export class RePurchaseWeeklyIncomeComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
