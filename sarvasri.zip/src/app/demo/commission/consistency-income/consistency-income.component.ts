import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-consistency-income',
  templateUrl: './consistency-income.component.html',
  styleUrls: ['./consistency-income.component.scss']
})
export class ConsistencyIncomeComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
