import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-basic-carousel',
  templateUrl: './basic-carousel.component.html',
  styleUrls: ['./basic-carousel.component.scss']
})
export class BasicCarouselComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
