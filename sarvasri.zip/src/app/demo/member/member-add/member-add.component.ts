import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-member-add',
  templateUrl: './member-add.component.html',
  styleUrls: ['./member-add.component.scss']
})
export class MemberAddComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
