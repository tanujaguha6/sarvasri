import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-member-view',
  templateUrl: './member-view.component.html',
  styleUrls: ['./member-view.component.scss']
})
export class MemberViewComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
