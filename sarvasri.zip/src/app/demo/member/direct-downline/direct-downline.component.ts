import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-direct-downline',
  templateUrl: './direct-downline.component.html',
  styleUrls: ['./direct-downline.component.scss']
})
export class DirectDownlineComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
