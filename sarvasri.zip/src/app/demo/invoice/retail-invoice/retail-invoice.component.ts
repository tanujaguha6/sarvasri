import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-retail-invoice',
  templateUrl: './retail-invoice.component.html',
  styleUrls: ['./retail-invoice.component.scss']
})
export class RetailInvoiceComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
