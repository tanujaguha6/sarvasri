import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-retail-package-invoice',
  templateUrl: './retail-package-invoice.component.html',
  styleUrls: ['./retail-package-invoice.component.scss']
})
export class RetailPackageInvoiceComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
