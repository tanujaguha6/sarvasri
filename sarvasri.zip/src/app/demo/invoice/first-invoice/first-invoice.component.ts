import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-first-invoice',
  templateUrl: './first-invoice.component.html',
  styleUrls: ['./first-invoice.component.scss']
})
export class FirstInvoiceComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
