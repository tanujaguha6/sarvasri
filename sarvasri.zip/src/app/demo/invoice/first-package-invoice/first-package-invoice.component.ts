import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-first-package-invoice',
  templateUrl: './first-package-invoice.component.html',
  styleUrls: ['./first-package-invoice.component.scss']
})
export class FirstPackageInvoiceComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
