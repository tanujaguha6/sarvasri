import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-theme-static',
  templateUrl: './theme-static.component.html',
  styleUrls: ['./theme-static.component.scss']
})
export class ThemeStaticComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
