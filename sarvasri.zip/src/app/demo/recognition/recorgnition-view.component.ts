import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-recorgnition-view',
  templateUrl: './recorgnition-view.component.html',
  styleUrls: ['./recorgnition-view.component.scss']
})
export class RecorgnitionViewComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
