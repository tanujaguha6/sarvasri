import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-re-purchase',
  templateUrl: './re-purchase.component.html',
  styleUrls: ['./re-purchase.component.scss']
})
export class RePurchaseComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
