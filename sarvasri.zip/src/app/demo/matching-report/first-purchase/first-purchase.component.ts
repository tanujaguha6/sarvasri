import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-first-purchase',
  templateUrl: './first-purchase.component.html',
  styleUrls: ['./first-purchase.component.scss']
})
export class FirstPurchaseComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
