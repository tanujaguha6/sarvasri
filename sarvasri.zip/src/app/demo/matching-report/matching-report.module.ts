import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { MatchingReportRoutingModule } from './matching-report-routing.module';



@NgModule({
  declarations: [],
  imports: [
    CommonModule,
    MatchingReportRoutingModule
  ]
})
export class MatchingReportModule { }
